#!/bin/bash

./maxwavevpn.app/Contents/MacOS/maxwavevpn
